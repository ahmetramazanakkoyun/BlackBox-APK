1) github.com'da yeni bir repo ac (ornek: bb-build), bu klasordeki .github/workflows/build-blackbox.yml dosyasini ayni yol ile yukle.
2) Repo > Actions > "Build BlackBox APK" > Run workflow. 10-20 dk surer.
3) Bitince calismanin altindaki Artifacts > BlackBox-debug-apk indir, zip'ten cikan universal APK'yi (adinda "universal" gecen) telefona kur.
4) Uygulamada "+" ile Top Lords'u secip klonla, ac ve giris yap. Cok klon icin ayni uygulamayi farkli klon (user) numaralarina ekle.
